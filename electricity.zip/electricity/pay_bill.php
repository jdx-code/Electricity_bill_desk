<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.html");
  }
	  require_once 'connect.php';

	  $b_id = $_POST['b_id'];
	  	  
	  $date = date('d/m/Y h:i:s', time());
	  
	 
	  $sql   = "INSERT INTO paid_bill_info (pay_id,b_id,paid_on,c_id) VALUES (DEFAULT,'$b_id','$date','" . $_SESSION['c_id'] . "')";
	  $query = mysqli_query($conn,$sql);

	  if($query){
	  	$sql1 = "UPDATE bill_info SET status = '1' WHERE bill_no = '$b_id'";
  		$query1 = mysqli_query($conn,$sql1);
	  }
?>