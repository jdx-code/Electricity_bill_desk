<?php
 $hostname="localhost";
 $username="root";
 $database="db_electricity";
 $password="";
 $conn = mysqli_connect($hostname,$username,$password,$database);
 if(!$conn){
 die("could not connect database...");
 }
?>
