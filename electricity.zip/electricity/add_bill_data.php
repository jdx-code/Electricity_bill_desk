<?php
  require_once 'connect.php';

  $service_tax = 0.5;
  $c_id = $_POST['c_id'];
  $unit_consumed = $_POST['unit_consumed'];
  if($unit_consumed <= 120) {
    $per_unit_charge = 5.65;
  } else {
    $per_unit_charge = 6.90;
  }
  $total_amount = $unit_consumed * $per_unit_charge * $service_tax;
  $c_bill_date = $_POST['c_bill_date'];
  $c_due_date = $_POST['c_due_date'];
 
  // echo $c_id;
  // echo $c_bill_amt;
  // echo $c_bill_date;
  // echo $c_due_date;

  $sql = "INSERT INTO meter_reading (mr_id,unit_consumed,per_unit_charge,service_tax,total_amount,c_id) VALUES (DEFAULT,'$unit_consumed','$per_unit_charge','$service_tax','$total_amount','$c_id')";
  $query = mysqli_query($conn,$sql);

  $sql = "INSERT INTO bill_info (bill_no, cus_id, bill_amt, bill_date, bill_due, status) VALUES (DEFAULT,'$c_id','$total_amount','$c_bill_date','$c_due_date','0')";

   $query = mysqli_query($conn,$sql);
   header("Location:view_pending_pay.php");

  
  
?>