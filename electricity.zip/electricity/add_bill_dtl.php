
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/screen.css" />

<title>Mountainously Simple by Bryant Smith</title>
</head>-->

<!--<body>
    <div id="main">
          <div id="header">
             <!--   <div id="headerTitle">THIS IS YOUR ADMIN DASHBOARD</div>-->
           <!-- <div id="headerSubText">Online Portal for Electricity Bills</div>-->
      <!--      </div>
    
    
    <div id="content">
    <div id="columnOne">
      <h1><a href="#"></a></h1>
        <h3></h3>
        <div class="content">
          <p></p><br />
            <blockquote>
            	<p></p>
	<h1><a href="add_record.html">ADD NEW RECORD</a><br><
                                              
                       
    
    
    </div>
    </div>
           <!-- <div id="footer"><a href="index.php">Development</a> by <a href="index.php">Asha Chetry</a></div>
        
   </div>-->
<!--</body>
</html>--><
<html>
<head>
	<title> ADMIN - ADD RECORD</title>
</head>
<body>
	Search from here
	<p>
	<form name="view_bill_form" action="view_add_bill.php" method="post">
		Customer ID :<input type="text" name="c_id" value=""><br>
		
		<input type="submit" name="add" value="VIEW">
	</form>
</p>
</body>
</html>