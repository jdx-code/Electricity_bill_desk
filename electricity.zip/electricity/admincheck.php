<?php
session_start();
require_once 'connect.php';
$username = $_POST['uname'];
$password  = $_POST['pass'];
$sql   = "SELECT * FROM admin WHERE username ='$username' AND password ='$password'";
$result = mysqli_query($conn,$sql);
$count  = mysqli_num_rows($result);
$row    = mysqli_fetch_array($result);
if($count==1){
  $_SESSION["user_id"] = $row[user_id];
  $_SESSION["username"] = $row[username];
  header("location: admin_dashboard.php");
}
else{
  $error = "Your username and password is incorrect";
  echo $error;
}
?>
