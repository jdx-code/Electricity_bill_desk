 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/screen.css" />
<title>Mountainously Simple by Bryant Smith</title>
 <?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.html");
  }
  require_once 'connect.php';
  $c_id = $_GET['c_id'];
?>
<form name="up_cus_form" action="up_data.php" method="post">
  <table class="table table-striped">
    <thead>
      <tr>
        <th scope="col">Customer Name</th>
        <th scope="col">Customer Phone</th>
        <th scope="col">Customer Address</th>        
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM customers where c_id = '$c_id'";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
    ?>
    
    <tbody>
      <tr>
        <td>
          <input type="text" name="c_name" value="<?php echo $row['c_name'];?>">
        </td>
        <td>
          <input type="text" name="c_phone" value="<?php echo $row['c_phone'];?>">
        </td>
         <td>
          <input type="text" name="c_address" value="<?php echo $row['c_address'];?>">
        </td>

        <input type="hidden" name="c_id" value="<?php echo $row['c_id'];?>">

        <td>
          <input type="submit" name="sub" value"UPDATE">
        </td>
      </tr>
    </tbody>
    <?php
     }
    ?>    
  </table>
</form>

