<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.html");
  }
  require_once 'connect.php';

  $c_id    = $_POST['c_id'];
  $c_name    = $_POST['c_name'];
  $c_phone   = $_POST['c_phone'];
  $c_address = $_POST['c_address'];
  
  $sql   =  "UPDATE customers SET 
             c_name = '$c_name', 
             c_phone  = '$c_phone',
             c_address = '$c_address'
             WHERE c_id = '$c_id'";
  $query = mysqli_query($conn,$sql);
  header('Location: update_record.php');
?>