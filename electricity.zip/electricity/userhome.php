<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.html");      
  }
  echo "WELCOME USER " .$_SESSION["username"]. ", THIS IS YOUR HOMEPAGE :)";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/screen.css" />
<title>Mountainously Simple by Bryant Smith</title>
</head>

<body>
    <div id="main">
          <div id="header">
                <div id="headerTitle">Electricity Bill Payment</div>
            <div id="headerSubText">Online Portal for Electricity Bills</div>
            </div>
    
    
    <div id="content">
	<p>
		
	</p>
	<hr>
	<p>
	<a href="view_new_bill.php">VIEW NEW BILL</a><br>
	<a href="view_paid_bills.php">VIEW PAID BILLS</a><br>
	<a href="logout.php">LOGOUT</a>
	</p>
    </div>  
   
    
<p>
<!-- AddThis Button BEGIN -->
<a href="http://www.addthis.com/bookmark.php" onclick="addthis_url   = location.href; addthis_title = document.title; return addthis_click(this);" target="_blank"><img src="http://s7.addthis.com/static/btn/lg-addthis-en.gif" width="125" height="16" border="0" alt="Bookmark and Share" /></a><script type="text/javascript">var addthis_pub = "bugmenot";</script><script type="text/javascript" src="http://s7.addthis.com/js/widget.php?v=10"></script>  
<!-- AddThis Button END -->
</p>
    
    
    </div>
    </div>
            <div id="footer"><a href="http://www.aszx.net">web development</a> by <a href="http://www.bryantsmith.com">bryant smith</a></div>
        
   </div>
</body>
</html>