<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/screen.css" />
<title>Mountainously Simple by Bryant Smith</title>
</head>

<body>
    <div id="main">
          <div id="header">
                <div id="headerTitle">Electricity Bill Payment</div>
            <div id="headerSubText">Online Portal for Electricity Bills</div>
            </div>
    
    
    <div id="content">
    <div id="columnOne">
      <h1><a href="#"></a></h1>
        <h3></h3>
        <div class="content">
          <p></p><br />
            <blockquote>
          		<h2>ADMIN LOGIN AREA</h2>
                <div id="userform">
                    <form name="adminform" action="admincheck.php" method="post">
                        <table>
                            <tr>
                                <td>
                                  <h1>ADMIN NAME  </h1>
                                </td>
                                <td>
                                  <input type="text" name="uname" value=""></br>  
                                </td>
                            </tr>
                            <tr>
                                <td>
                                  <h1>PASSWORD </h1>
                                </td>
                                <td>
                                  <input type="password" name="pass" value="">    
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                 <input type="submit" name="" value="LOGIN PLZ">
                                </td>                                
                            </tr>
                        </table>
                    </form>                     
                </div>  
                
            </blockquote>
        <p></p>   

          <div class="comments"><a href="#"></a></div>
        </div>

        <h1><a href="#"></a></h1>
        <h3></h3>
        <div class="content">
          <p></p><br />
        <p></p>        
        <div class="comments"><a href="#"></a></div>
    </div>
    </div>
    
   
    <div id="columnTwo">
    <!-- <h2>Site Links</h2> -->
    <div class="links">
    
    </div>
   
    <!-- <h2></h2>
    <div class="links">
    <ul>
    <li><a href="#"></a></li>
      <li><a href="#">Affiliate 2</a></li>
        <li><a href="#">Affiliate 3</a></li>
        <li><a href="#">Affiliate 4</a></li>
        <li><a href="#">Affiliate 5</a></li>
    </ul>
     --><!-- </div> -->
   
    
    <!-- <h2>External Links</h2> -->
    <!-- <div class="links">
    <ul>
    <li><a href="http://www.google.com">Google</a></li>
      <li><a href="http://www.yahoo.com">Yahoo</a></li>
        <li><a href="http://www.digg.com">Digg</a></li>
        <li><a href="http://www.reddit.com">Reddit</a></li>
        <li><a href="http://www.aszx.com">ASZX</a></li>
    </ul>
    </div><br />
     -->
<p>
<!-- AddThis Button BEGIN -->
<!-- AddThis Button END -->
</p>
    
    
    </div>
    </div>
            <div id="footer"><a href="index.php">Development</a> by <a href="index.php">Asha Chetry</a></div>
        
   </div>
</body>
</html>