<?php
require_once 'connect.php';

$c_id = $_GET['c_id'];
$sql     = "DELETE FROM customers where c_id = '$c_id'";
$query   = mysqli_query($conn,$sql);
header('Location: delete_record.php');
?>
