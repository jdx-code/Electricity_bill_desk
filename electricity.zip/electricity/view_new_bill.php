<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.html");
  }
  require_once 'connect.php';
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/screen.css" />
<title>Mountainously Simple by Bryant Smith</title>
</head>

<body>
    <div id="main">
          <div id="header">
                <div id="headerTitle">Electricity Bill Payment</div>
            <div id="headerSubText">Online Portal for Electricity Bills</div>
            </div>
    
    
    <div id="content">
  <p>
    
  </p>
  <hr>
  <p>
  <table class="table table-striped" border="1">
    <thead>
      <tr>
        <th scope="col">User Name</th>
        <th scope="col">User Phone</th>
        <th scope="col">User Bill</th>
        <th scope="col">Bill Date</th>
        <th scope="col">Bill Due</th>         
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM customers,users,bill_info WHERE customers.c_id = bill_info.cus_id AND users.c_id = bill_info.cus_id AND users.c_id = '" . $_SESSION['c_id'] . "' AND status = '0'";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){

    ?>
    <form name="payment_form" action="pay_bill.php" method="post">
    <tbody>
      <tr>
        <td>
          <input type="text" name="u_name" value="<?php
            echo $row['u_name'];
          ?>"  disabled>
          
        </td>
        <td>
          <input type="text" name="u_phone" value="<?php
            echo $row['u_phone'];
          ?>"  disabled>
          
        </td>
        <td>
          <input type="text" name="bill_amt" value="<?php
            echo $row['bill_amt'];
          ?>"  disabled>
          
        </td>
        <td>
          <input type="text" name="bill_date" value="<?php
            echo $row['bill_date'];
          ?>"  disabled>
          
        </td>
        <td>
          <input type="text" name="bill_due" value="<?php
            echo $row['bill_due'];
          ?>"  disabled>
          
        </td>
        <input type="hidden" name="b_id" value="<?php
            echo $row['bill_no'];
          ?>">
        <td>
          <input type="submit" name="submit" value="PAY NOW">
        </td>
       
          <?php
          }
          ?>
      </tr>
    </tbody>  
    </form>
    
  </table>


  </p>
    </div>  
   
    
<p>
<!-- AddThis Button BEGIN -->
<a href="http://www.addthis.com/bookmark.php" onclick="addthis_url   = location.href; addthis_title = document.title; return addthis_click(this);" target="_blank"><img src="http://s7.addthis.com/static/btn/lg-addthis-en.gif" width="125" height="16" border="0" alt="Bookmark and Share" /></a><script type="text/javascript">var addthis_pub = "bugmenot";</script><script type="text/javascript" src="http://s7.addthis.com/js/widget.php?v=10"></script>  
<!-- AddThis Button END -->
</p>
    
    
    </div>
    </div>
            <div id="footer"><a href="http://www.aszx.net">web development</a> by <a href="http://www.bryantsmith.com">bryant smith</a></div>
        
   </div>
</body>
</html>