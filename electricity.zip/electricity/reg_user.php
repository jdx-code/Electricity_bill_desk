<?php
	  require_once 'connect.php';

	  $uname = $_POST['uname'];
	  $pass = $_POST['pass'];
	  $phone = $_POST['phone'];
	  $email = $_POST['email'];
	  $gender = $_POST['gender'];
	  $dob = $_POST['dob'];
	  $address = $_POST['address'];
	  $c_id = $_POST['c_id'];
	  
	 
	  $sql   = "INSERT INTO users (u_id,u_name,u_pass,u_phone,u_email,gender,dob,address,c_id) VALUES (DEFAULT,'$uname','$pass','$phone','$email','$gender','$dob','$address','$c_id')";
	  $query = mysqli_query($conn,$sql);
?>

