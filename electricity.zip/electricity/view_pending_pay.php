<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/screen.css" />
<title>Mountainously Simple by Bryant Smith</title>
</head>
<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.html");
  }
  require_once 'connect.php';
?>
  <table class="table table-striped" border="1">
    <thead>
      <tr>        
        <th scope="col">Customer Name</th>
        <th scope="col">Customer Phone</th>
        <th scope="col">Customer Address</th>
        <th scope="col">Bill Amount</th>
        <th scope="col">Bill Date</th>
        <th scope="col">Bill Due Date</th>         
      </tr>
    </thead>

    <?php
      $sql   = "SELECT * FROM users, bill_info WHERE users.u_id = bill_info.cus_id AND bill_info.status = 0";
      $result = mysqli_query($conn,$sql);
      while($row = mysqli_fetch_array($result)){
    ?>
    <tbody>
      <tr>
        <!-- <td>
          <?php
           
          ?>
        </td> -->
        <td>
          <?php
            echo $row['u_name'];
          ?>
        </td>
        <td>
          <?php
            echo $row['u_phone'];
          ?>
        </td>
        <td>
          <?php
            echo $row['address'];
          ?>
        </td>
        <td>
          <?php
            echo $row['bill_amt'];
          ?>
        </td>
        <td>
          <?php
            echo $row['bill_date'];
          ?>
        </td>
        <td>
          <?php
            echo $row['bill_due'];
          ?>
        </td>
       
          <?php
          }
          ?>
      </tr>

    </tbody>
  </table>
