<?php
session_start();
require_once 'connect.php';
$username = $_POST['uname'];
$password  = $_POST['pass'];
$sql   = "SELECT * FROM users WHERE u_name ='$username' AND u_pass ='$password'";
$result = mysqli_query($conn,$sql);
$count  = mysqli_num_rows($result);
$row    = mysqli_fetch_array($result);
if($count==1){
  $_SESSION["user_id"] = $row[u_id];
  $_SESSION["username"] = $row[u_name];
  $_SESSION["c_id"] = $row[c_id];
  header("location: userhome.php");
}
else{
  $error = "Your username and password is incorrect";
  echo $error;
}
?>
