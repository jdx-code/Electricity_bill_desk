<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/screen.css" />
<title>Mountainously Simple by Bryant Smith</title>
</head>
<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.html");
  }
  require_once 'connect.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Admin View</title>
</head>
<body>
	
	<h1><a href="view_cust.php">View All Customers</a><br></h1>
	<h1><a href="view_pending_pay.php">View Pending Payment </a><br></h1>


</body>
</html>