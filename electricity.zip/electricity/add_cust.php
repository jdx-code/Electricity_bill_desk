<?php
  require_once 'connect.php';

  $c_name = $_POST['c_name'];
  $c_phone = $_POST['c_phone'];
  $c_address = $_POST['c_address'];
 
  $sql   = "INSERT INTO customers (c_id,c_name,c_phone,c_address) VALUES (DEFAULT,'$c_name','$c_phone','$c_address')";
  $query = mysqli_query($conn,$sql);
  header("Location:view_cust.php");
?>