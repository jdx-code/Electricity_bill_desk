<?php
  session_start();
  if(!isset($_SESSION["user_id"])) {
      header("Location:index.html");      
  }
  echo "WELCOME ".$_SESSION["username"]. ", THIS IS YOUR ADMIN DASHBOARD :)";
?>
<!--<!DOCTYPE html>
<html>
<head>
	<title> ADMIN DASHBOARD</title>
</head>-->
<!--<body>
	<p></p>
	<a href="add_record.html">ADD NEW RECORD</a><br>
	<a href="delete_record.php">DELETE RECORD</a><br>
	<a href="update_record.php">UPDATE RECORD</a><br>
	<a href="view_record.php">VIEW RECORD</a><br>
	<a href="add_bill_dtl.php">ADD BILL DETAILS</a><br>
	<a href=".php">LOGOUT</a>
</body>
</html>-->

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/screen.css" />

<title>Mountainously Simple by Bryant Smith</title>
</head>-->

<body>
    <div id="main">
          <div id="header">
             <!--   <div id="headerTitle">THIS IS YOUR ADMIN DASHBOARD</div>-->
           <!-- <div id="headerSubText">Online Portal for Electricity Bills</div>-->
            </div>
    
    
    <div id="content">
    <div id="columnOne">
      <h1><a href="#"></a></h1>
        <h3></h3>
        <div class="content">
          <p></p><br />
            <blockquote>
            	<p></p>
	<h1><a href="add_record.html">ADD NEW RECORD</a><br></h1>
	<h1><a href="delete_record.php">DELETE RECORD</a><br></h1>
	<h1><a href="update_record.php">UPDATE RECORD</a><br></h1>
	<h1><a href="view_record.php">VIEW RECORD</a><br></h1>
	<h1><a href="add_bill_dtl.php">ADD BILL DETAILS</a><br></h1>
	<h1><a href="logout.php">LOGOUT</a></h1>
               <!-- <div id="userform">
                    <form name="userform" action="usercheck.php" method="post">
                        <table>
                            <tr>
                                <td>
                                  <h1>USER NAME  </h1>
                                </td>
                                <td>
                                  <input type="text" name="uname" value=""></br>  
                                </td>
                            </tr>
                            <tr>
                                <td>
                                  <h1>PASSWORD </h1>
                                </td>
                                <td>
                                  <input type="password" name="pass" value="">    
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    &nbsp;
                                </td>
                                <td>
                                 <input type="submit" name="" value="LOGIN PLZ">   
                                 or <a href="user_reg.html">Register</a>
                                </td>                                
                            </tr>
                        </table>
                    </form>                   
                 </div>     
        
                
            </blockquote>
        <p></p>   

          <div class="comments"><a href="#"></a></div>
        </div>

        <h1><a href="#"></a></h1>
        <h3></h3>
        <div class="content">
          <p></p><br />
        <p></p>        
        <div class="comments"><a href="#"></a></div>
    </div>
    </div>
    
   
    <div id="columnTwo">
     <h2>Site Links</h2> -->
   <!-- <div class="links">
    
    </div>
   
    <h2></h2>
    <div class="links">
    <ul>
    <li><a href="#"></a></li>
      <li><a href="#">Affiliate 2</a></li>
        <li><a href="#">Affiliate 3</a></li>
        <li><a href="#">Affiliate 4</a></li>
        <li><a href="#">Affiliate 5</a></li>
    </ul>
     --><!-- </div> -->
   
    
    <!-- <h2>External Links</h2> -->
    <!-- <div class="links">
    <ul>
    <li><a href="http://www.google.com">Google</a></li>
      <li><a href="http://www.yahoo.com">Yahoo</a></li>
        <li><a href="http://www.digg.com">Digg</a></li>
        <li><a href="http://www.reddit.com">Reddit</a></li>
        <li><a href="http://www.aszx.com">ASZX</a></li>
    </ul>
    </div><br />
     -->
<!--<p>
 AddThis Button BEGIN 
 AddThis Button END 
</p>-->
    
    
    </div>
    </div>
           <!-- <div id="footer"><a href="index.php">Development</a> by <a href="index.php">Asha Chetry</a></div>
        
   </div>-->
</body>
</html>