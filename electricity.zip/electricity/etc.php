<td>
<?php
if($row['bill_amt'] != ""){
?>

  <input type="text" name="c_bill_amt" value="<?php echo $row['bill_amt'];?>" readonly>            
<?php
} else {
?>
  <input type="text" name="c_bill_amt" value="">
<?php
}
?>
</td>



/////////////////////



<td>
          <input type="text" name="c_phone" value="<?php echo $row['c_phone'];?>"  disabled>
        </td>

        <td>
          <input type="text" name="c_address" value="<?php echo $row['c_address'];?>"  disabled>
        </td>
        
